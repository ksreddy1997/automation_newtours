package com.sree.setup;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class DriverSetUp {

   public static WebDriver driver;
   String url ="http://newtours.demoaut.com/";
   
   public WebDriver driversetup(String browser)
   {
	   if(browser.equalsIgnoreCase("chrome"))
	   {
		   System.setProperty("webdriver.chrome.driver", "C:\\Users\\Sreek\\eclipse-workspace\\Assignment\\src\\drivers\\chromedriver.exe");
		   ChromeOptions options = new ChromeOptions();
		   options.addArguments("--disable-notifications");
		   driver = new ChromeDriver(options);
		   driver.manage().window().maximize();
		   driver.get(url);
		   driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		   
		   return driver;
	   }
	return null;
	   
   }
   
   public void driverexit()
   {
	   driver.close();
   }
}
