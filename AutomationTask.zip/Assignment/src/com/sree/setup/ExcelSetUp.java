package com.sree.setup;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelSetUp {

	FileInputStream fis;
    FileOutputStream fos;
    XSSFWorkbook wb;
    XSSFSheet sht1, sht2, sht3;
    XSSFRow row;
    XSSFCell cell;
    public String excelgetdata1(int r, int c) throws Exception
    {
                                    String datapath="C:\\Users\\Sreek\\eclipse-workspace\\Assignment\\Data Sheet.xlsx";
                                    fis = new FileInputStream(datapath);
                                    wb = new XSSFWorkbook(fis);
                                    	sht1 = wb.getSheet("Reg Test Data");
                                    	String data= new DataFormatter().formatCellValue(sht1.getRow(r).getCell(c));
                                    	return data;
    }
    public String excelgetdata2(int r, int c) throws Exception
    {
                                    String datapath="C:\\Users\\Sreek\\eclipse-workspace\\Assignment\\Data Sheet.xlsx";
                                    fis = new FileInputStream(datapath);
                                    wb = new XSSFWorkbook(fis);
                                   
                                    	sht2 = wb.getSheet("Sign In Test Data");
                                    	String data= new DataFormatter().formatCellValue(sht2.getRow(r).getCell(c));
                                    	return data;
    }
    public String excelgetdata3(int r, int c) throws Exception
    {
                                    String datapath="C:\\Users\\Sreek\\eclipse-workspace\\Assignment\\Data Sheet.xlsx";
                                    fis = new FileInputStream(datapath);
                                    wb = new XSSFWorkbook(fis);
                                    	sht3 = wb.getSheet("Book Flight Test Data");
                                        String data= new DataFormatter().formatCellValue(sht3.getRow(r).getCell(c));
                                        return data;
    }
    
    public void excelwritedata(int r, int c, String str, String datapath) throws Exception
    {
                        
                                    fis = new FileInputStream(datapath);
                                    wb = new XSSFWorkbook(fis);
                                    //sh = wb.createSheet("Sheet1");
                                    //sh.createRow(r).createCell(c).setCellValue(str);
                                    fos = new FileOutputStream(str);
                                    wb.write(fos);
                                    fos.close();
    }
}
