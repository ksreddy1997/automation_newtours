package com.sree.elements;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.sree.setup.DriverSetUp;
import com.sree.setup.ExcelSetUp;

public class SignIn_Elements {

	ExcelSetUp es = new ExcelSetUp();
   XSSFSheet sht2;
	public SignIn_Elements()
	{
		PageFactory.initElements(DriverSetUp.driver, this);
	}
	
	Actions act = new Actions(DriverSetUp.driver);
	
	//SignIn Page 
		@FindBy(xpath="//a[text()='SIGN-ON']")
		private WebElement signon;
		
		// Sign on Username 
		@FindBy(xpath="//input[@name='userName']")
		private WebElement signin_username;
		
		//Sign on Pwd 
		
		@FindBy(xpath="//input[@name='password']")
		private WebElement signin_pwd;
		
		//Sign On Submit Button
		@FindBy(xpath="//input[@name='login']")
		private WebElement login;
		
		// Sign In Submit Method
		public void signsubmit()
		{
			login.click();
		}
		//Sign In Pwd Method
		public void signinpwd() throws Exception
		{
			signin_pwd.sendKeys(es.excelgetdata2(1, 1));
		}
		//Sign on User Name Method
		public void signinusername() throws Exception
		{
			
			signin_username.sendKeys(es.excelgetdata2(1, 0));
		}
		// Sign on Method
		public void signon()
		{
			act.click(signon).build().perform();
		}
		
	
}
