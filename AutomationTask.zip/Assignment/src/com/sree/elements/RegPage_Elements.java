package com.sree.elements;

import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;

import com.sree.setup.DriverSetUp;
import com.sree.setup.ExcelSetUp;

public class RegPage_Elements {
	
	ExcelSetUp es = new ExcelSetUp();
	XSSFSheet sht1;

	public RegPage_Elements()
	{
		PageFactory.initElements(DriverSetUp.driver, this);
	}
	
	Actions act = new Actions(DriverSetUp.driver);
	// Reg Page Open Element
	@FindBy(xpath="//a[text()='REGISTER']")
	private WebElement regpage;
	
	// First Name 
	@FindBy(xpath="//input[@name='firstName']")
	private WebElement fname;
	
	//last Name 
	@FindBy(xpath="//input[@name='lastName']")
	private WebElement lname;
	
	//Phone
	@FindBy(xpath="//input[@name='phone']")
	private WebElement phone;
	
	//Email
	@FindBy(xpath="//input[@name='userName']")
	private WebElement email;
	
	//Address1
	@FindBy(xpath="//input[@name='address1']")
	private WebElement addr1;
	
	//Address2
	@FindBy(xpath="//input[@name='address2']")
	private WebElement addr2;
	
	//City
	@FindBy(xpath="//input[@name='city']")
	private WebElement city;
	
	//State
	@FindBy(xpath="//input[@name='state']")
	private WebElement state;
	
	//Postalcode
	@FindBy(xpath="//input[@name='postalCode']")
	private WebElement postal;
	
	//Country
	//@FindBys(@FindBy(xpath="//select[@name='country']"))
	@FindBy(xpath="//select[@name='country']")
	private WebElement country;
	
	//Username
	@FindBy(xpath="//input[@name='email']")
	private WebElement username;
	
	//Password
	@FindBy(xpath="//input[@name='password']")
	private WebElement pwd;
	
	//Confirm Password
	@FindBy(xpath="//input[@name='confirmPassword']")
	private WebElement ConfirmPwd;
	
	//Submit
	@FindBy(xpath="//input[@name='register']")
	private WebElement subbtn;
	
	
	// Reg Page Method
	public void registerpage()
	{
			   act.click(regpage).build().perform();
	}
	
	//First Name Method
	public void firstname() throws Exception
	{
		//fname.sendKeys("Sreekanth");
		fname.sendKeys(es.excelgetdata1(1, 0));
	}
	
	//Last name Method
	public void lastname() throws Exception
	{
		//lname.sendKeys("Reddy");
		lname.sendKeys(es.excelgetdata1(1, 1));
	}
	
	//Phone Method
	public void phone() throws Exception
	{
		//phone.sendKeys("9491763295");
		phone.sendKeys(es.excelgetdata1(1, 2));
	}
	
	//Email Method
	public void email() throws Exception
	{
		//email.sendKeys("sreekanthreddy145@gmail.com");
		email.sendKeys(es.excelgetdata1(1, 3));
	}
	
	//Address Method
	public void address() throws Exception
	{
		//addr1.sendKeys("Nellore");
		addr1.sendKeys(es.excelgetdata1(1, 4));
		addr2.sendKeys("");
	}
	
	//City Method
	public void city() throws Exception
	{
		//city.sendKeys("Nellore");
		city.sendKeys(es.excelgetdata1(1, 5));
	}
	
	//State Method
	public void state() throws Exception
	{
		//state.sendKeys("Andhra Pradesh");
		state.sendKeys(es.excelgetdata1(1, 6));
	}
	
	//Postal Code Method
	public void postal() throws Exception
	{
		//postal.sendKeys("524240");
		postal.sendKeys(es.excelgetdata1(1, 7));
	}
	
	//Country Method
	public void country() throws Exception
	{
		//act.clickAndHold(country).sendKeys("India").build().perform();
		act.clickAndHold(country).sendKeys(es.excelgetdata1(1, 8)).build().perform();
	}
	
	//User Name Method
	public void username() throws Exception
	{
		//username.sendKeys("ksreddy1997");
		username.sendKeys(es.excelgetdata1(1, 9));
	}
	
	// Pwd Method
	public void password() throws Exception
	{
		//pwd.sendKeys("Anusha@1");
		pwd.sendKeys(es.excelgetdata1(1, 10));
	}
	
	//Confirm Password
	public void confirmpassword() throws Exception
	{
		//ConfirmPwd.sendKeys("Anusha@1");
		ConfirmPwd.sendKeys(es.excelgetdata1(1, 11));
	}
	
	//Submit Button
	public void submitbutton() throws Exception
	{
		if(es.excelgetdata1(1, 10).contentEquals(es.excelgetdata1(1, 11)))
		{
			subbtn.click();
		}
		
		else 
		{
			System.out.println("Password Doesn't Match");
		}
	}
}
