package com.sree.elements;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.sree.setup.DriverSetUp;
import com.sree.setup.ExcelSetUp;

public class BookFlight_RoundTrip_Elements {

	ExcelSetUp es = new ExcelSetUp();
	XSSFSheet sht3;

	public BookFlight_RoundTrip_Elements()
	{
		PageFactory.initElements(DriverSetUp.driver, this);
	}
	
	Actions act = new Actions(DriverSetUp.driver);
	//Round Trip Button
			@FindBy(xpath="//input[@value='roundtrip']")
			private WebElement roundtrip;
			
			public void roundtrip()
			{
			    roundtrip.click();
			}
			//Count of Passengers
			@FindBy(xpath="//select[@name='passCount']")
			private WebElement passcnt;
			
			public void passcount() throws Exception
			{
			act.clickAndHold(passcnt).sendKeys(es.excelgetdata3(1, 0)).build().perform();
			}
			//Departure Port
			@FindBy(xpath="//select[@name='fromPort']")
			private WebElement fromport;
			
			public void fromport() throws Exception
			{
			act.clickAndHold(fromport).sendKeys(es.excelgetdata3(1, 2)).build().perform();
			}
			//On Date
			@FindBy(xpath="//select[@name='fromMonth']")
			private WebElement ondatemonth;
			@FindBy(xpath="//select[@name='fromDay']")
			private WebElement ondate;
			
			public void ondate() throws Exception
			{
			act.clickAndHold(ondatemonth).sendKeys(es.excelgetdata3(1, 3)).build().perform();
			act.clickAndHold(ondate).sendKeys(es.excelgetdata3(1, 4)).build().perform();
			}
			//Arriving 
			@FindBy(xpath="//select[@name='toPort']")
			private WebElement toport;
			
			public void toport() throws Exception
			{
			act.clickAndHold(toport).sendKeys(es.excelgetdata3(1, 5)).build().perform();
			}
			//return date
			@FindBy(xpath="//select[@name='toMonth']")
			private WebElement todatemonth;
			@FindBy(xpath="//select[@name='toDay']")
			private WebElement todate;
			
			public void todate() throws Exception
			{
			act.clickAndHold(todatemonth).sendKeys(es.excelgetdata3(1, 6)).build().perform();
			act.clickAndHold(todate).sendKeys("").build().perform();
			}
			// Economy Class
			@FindBy(xpath="//input[@value='Coach']")
			private WebElement economy;
			
			public void economy()
			{
				economy.click();
			}
			
			//Business Class
			@FindBy(xpath="//input[@value='Business']")
			private WebElement business;
			
			public void business()
			{
				business.click();
			}
			
			//First Class
			@FindBy(xpath="//input[@value='First']")
			private WebElement first;
			
			public void first()
			{
				first.click();
			}
			
			//Airline Preference
			@FindBy(xpath="//select[@name='airline']")
			private WebElement preference;
			
			public void airpreference() throws Exception
			{
				act.clickAndHold(preference).sendKeys(es.excelgetdata3(1, 7)).build().perform();
			}
			
			//Continue Button on Step 1
			@FindBy(xpath="//input[@name='findFlights']")
			private WebElement continue1;
			
			public void continue1()
			{
				continue1.click();
			}
			
			//Selecting the Departure Flight as Second one in the list
			@FindBy(xpath="(//tr/td[@rowspan]/input[@name='outFlight'])[2]")
			private WebElement depflight2;
			
			public void depflifghtname()
			{
				depflight2.click();
			}
			
			//Selecting the Return Flight as Scons one in the list
			@FindBy(xpath="(//tr/td[@rowspan]/input[@name='inFlight'])[2]")
			private WebElement arrivalflight2;
			
			public void arrivalflightname()
			{
				arrivalflight2.click();
			}
			
			//Clicking COntinue Button on Step 2
			@FindBy(xpath="//input[@name='reserveFlights']")
			private WebElement continue2;
			
			public void continue2()
			{
				continue2.click();
			}
			
			//Book Flight First Name
			@FindBy(xpath="//input[@name='passFirst0']")
			private WebElement firstname01;
			
			public void firstname01() throws Exception
			{
				firstname01.sendKeys(es.excelgetdata3(1, 8));
			}
			
			//Book Flight Last Name
			@FindBy(xpath="//input[@name='passLast0']")
			private WebElement lastname01;
			
			public void lastname01() throws Exception
			{
				lastname01.sendKeys(es.excelgetdata3(1,9));
			}
			
			//Meal Prefernce
			@FindBy(xpath="//select[@name='pass.0.meal']")
			private WebElement meal;
			
			public void meal() throws Exception
			{
				act.clickAndHold(meal).sendKeys(es.excelgetdata3(1, 10)).build().perform();
			}
			
			//Card Type
			@FindBy(xpath="//select[@name='creditCard']")
			private WebElement cardtype;
			
			public void cardtype() throws Exception
			{
				act.clickAndHold(cardtype).sendKeys(es.excelgetdata3(1, 11)).build().perform();
			}
			
			//Card Number
			@FindBy(xpath="//input[@name='creditnumber']")
			private WebElement cardnumber;
			
			public void cardnumber() throws Exception
			{
				cardnumber.sendKeys(es.excelgetdata3(1, 12));
			}
			
			//Expiration
			@FindBy(xpath="//select[@name='cc_exp_dt_mn']")
			private WebElement expmonth;
			@FindBy(xpath="//select[@name='cc_exp_dt_yr']")
			private WebElement expyear;
			
			public void expiration() throws Exception
			{
				act.clickAndHold(expmonth).sendKeys(es.excelgetdata3(1, 13)).build().perform();
				act.clickAndHold(expyear).sendKeys(es.excelgetdata3(1, 14)).build().perform();
			}
			
			//Card First Name
			@FindBy(xpath="//input[@name='cc_frst_name']")
			private WebElement ccfirstname;
			
			public void ccfname() throws Exception
			{
				ccfirstname.sendKeys(es.excelgetdata3(1, 15));
			}
			//Card Middle Name
			@FindBy(xpath="//input[@name='cc_mid_name']")
			private WebElement ccmiddlename;
			
			public void ccmname() throws Exception
			{
				ccmiddlename.sendKeys(es.excelgetdata3(1, 16));
			}
			
			//Card Last Name
			@FindBy(xpath="//input[@name='cc_last_name']")
			private WebElement cclastname;
			
			public void cclname() throws Exception
			{
				cclastname.sendKeys(es.excelgetdata3(1, 17));
			}
			
			//checkbox Ticketless
			@FindBy(xpath="(//input[@name='ticketLess'])[1]")
			private WebElement tktless;
			
			public void tktless()
			{
				tktless.click();
			}
			
			//Billing Address
			@FindBy(xpath="//input[@name='billAddress1']")
			private WebElement baddr1;
			@FindBy(xpath="//input[@name='billAddress2']")
			private WebElement baddr2;
			
			public void billingaddr() throws Exception
			{
				baddr1.clear();
				baddr1.sendKeys(es.excelgetdata3(1, 18));
				baddr2.sendKeys(es.excelgetdata3(1, 19));
			}
			
			// Billing City
			@FindBy(xpath="//input[@name='billCity']")
			private WebElement bcity;
			
			public void bcity() throws Exception
			{
				bcity.clear();
				bcity.sendKeys(es.excelgetdata3(1, 20));
			}
			
			//Billing State
			
			@FindBy(xpath="//input[@name='billState']")
			private WebElement billstate;
			
			public void billstate() throws Exception
			{
			    billstate.clear();
				billstate.sendKeys(es.excelgetdata3(1, 21));
			}
			
            //Billing Postal Code
			
			@FindBy(xpath="//input[@name='billZip']")
			private WebElement billzip;
			
			public void billzip() throws Exception
			{
				billzip.clear();
				billzip.sendKeys(es.excelgetdata3(1, 22));
			}
			
			//Billing State
			@FindBy(xpath="//select[@name='billCountry']")
			private WebElement billcountry;
			
			public void billcountry() throws Exception
			{
				act.clickAndHold(billcountry).sendKeys(es.excelgetdata3(1, 23)).build().perform();
			}
			
			//checkbox Delivery Address
			@FindBy(xpath="(//input[@name='ticketLess'])[2]")
			private WebElement delcheckbox;
			
			public void delcheckbox()
			{
				delcheckbox.click();
			}
			
			//Delivery Address
			@FindBy(xpath="//input[@name='delAddress1']")
			private WebElement deladdr1;
			@FindBy(xpath="//input[@name='delAddress2']")
			private WebElement deladdr2;
			
			public void deliveryaddr() throws Exception
			{
				deladdr1.clear();
				deladdr1.sendKeys(es.excelgetdata3(1, 24));
				deladdr2.sendKeys(es.excelgetdata3(1, 25));
			}
			
			// Billing City
			@FindBy(xpath="//input[@name='delCity']")
			private WebElement delcity;
			
			public void delcity() throws Exception
			{
				delcity.clear();
				delcity.sendKeys(es.excelgetdata3(1, 26));
			}
			
			//Billing State
			
			@FindBy(xpath="//input[@name='delState']")
			private WebElement delstate;
			
			public void deliverystate() throws Exception
			{
			    delstate.clear();
				delstate.sendKeys(es.excelgetdata3(1, 27));
			}
			
            //Billing Postal Code
			
			@FindBy(xpath="//input[@name='delZip']")
			private WebElement delzip;
			
			public void delzip() throws Exception
			{
				billzip.clear();
				billzip.sendKeys(es.excelgetdata3(1, 28));
			}
			
			//Billing State
			@FindBy(xpath="//select[@name='delCountry']")
			private WebElement delcountry;
			
			public void deliverycountry() throws Exception
			{
				act.clickAndHold(delcountry).sendKeys(es.excelgetdata3(1, 29)).build().perform();
			}
			
			//Continue Button on Step 3
			@FindBy(xpath="//input[@name='buyFlights']")
			private WebElement continue3;
			
			public void continue3() throws Exception
			{
				continue3.click();
				Robot r = new Robot();
				r.keyPress(KeyEvent.VK_CONTROL);
				r.keyPress(KeyEvent.VK_P);
				r.keyRelease(KeyEvent.VK_CONTROL);
				r.keyPress(KeyEvent.VK_ENTER);
				r.keyRelease(KeyEvent.VK_ENTER);
			}
			
			//Logout Button
			@FindBy(xpath="//img[@src='/images/forms/Logout.gif']")
			private WebElement logout;
			
			public void logout()
			{
				logout.click();
			}
			
			
			
}
