package com.sree.elements;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.sree.setup.DriverSetUp;
import com.sree.setup.ExcelSetUp;

public class BookFlight_Oneway_Elements {

	ExcelSetUp es = new ExcelSetUp();

	public BookFlight_Oneway_Elements()
	{
		PageFactory.initElements(DriverSetUp.driver, this);
	}
	
	Actions act = new Actions(DriverSetUp.driver);
			//One Way Button
			@FindBy(xpath="//input[@value='oneway']")
			private WebElement oneway;
			
			public void oneway()
			{
				oneway.click();
			}
			
			//Count of Passengers
			@FindBy(xpath="//select[@name='passCount']")
			private WebElement passcnt;
			
			public void passcount()
			{
			act.clickAndHold(passcnt).sendKeys("").build().perform();
			}
			//Departure Port
			@FindBy(xpath="//select[@name='fromPort']")
			private WebElement fromport;
			
			public void fromport()
			{
			act.clickAndHold(fromport).sendKeys("").build().perform();
			}
			//On Date
			@FindBy(xpath="//select[@name='fromMonth']")
			private WebElement ondatemonth;
			@FindBy(xpath="//select[@name='fromDay']")
			private WebElement ondate;
			
			public void ondate()
			{
			act.clickAndHold(ondatemonth).sendKeys("").build().perform();
			act.clickAndHold(ondate).sendKeys("").build().perform();
			}
			//Arriving 
			@FindBy(xpath="//select[@name='toPort']")
			private WebElement toport;
			
			public void toport()
			{
			act.clickAndHold(toport).sendKeys("").build().perform();
			}
			//return date
			@FindBy(xpath="//select[@name='toMonth']")
			private WebElement todatemonth;
			@FindBy(xpath="//select[@name='toDay']")
			private WebElement todate;
			
			public void todate()
			{
			act.clickAndHold(todatemonth).sendKeys("").build().perform();
			act.clickAndHold(todate).sendKeys("").build().perform();
			}
			// Economy Class
			@FindBy(xpath="//input[@value='Coach']")
			private WebElement economy;
			
			public void economy()
			{
				economy.click();
			}
			
			//Business Class
			@FindBy(xpath="//input[@value='Business']")
			private WebElement business;
			
			public void business()
			{
				business.click();
			}
			
			//First Class
			@FindBy(xpath="//input[@value='First']")
			private WebElement first;
			
			public void first()
			{
				first.click();
			}
			
			//Airline Preference
			@FindBy(xpath="//select[@name='airline']")
			private WebElement preference;
			
			public void airpreference()
			{
				act.clickAndHold(preference).sendKeys("").build().perform();
			}
			
			//Continue Button on Step 1
			@FindBy(xpath="//input[@name='findFlights']")
			private WebElement continue1;
			
			public void continue1()
			{
				continue1.click();
			}
			
			//Selecting the Departure Flight as Second one in the list
			@FindBy(xpath="(//tr/td[@rowspan]/input[@name='outFlight'])[2]")
			private WebElement depflight2;
			
			public void depflifghtname()
			{
				depflight2.click();
			}
			
			//Selecting the Return Flight as Scons one in the list
			@FindBy(xpath="(//tr/td[@rowspan]/input[@name='inFlight'])[2]")
			private WebElement arrivalflight2;
			
			public void arrivalflightname()
			{
				arrivalflight2.click();
			}
			
			//Clicking COntinue Button on Step 2
			@FindBy(xpath="//input[@name='reserveFlights']")
			private WebElement continue2;
			
			public void continue2()
			{
				continue2.click();
			}
			
			//Book Flight First Name
			@FindBy(xpath="//input[@name='passFirst0']")
			private WebElement firstname01;
			
			public void firstname01()
			{
				firstname01.click();
			}
			
			//Book Flight Last Name
			@FindBy(xpath="//input[@name='passLast0']")
			private WebElement lastname01;
			
			public void lastname01()
			{
				lastname01.click();
			}
			
			//Meal Prefernce
			@FindBy(xpath="//select[@name='pass.0.meal']")
			private WebElement meal;
			
			public void meal()
			{
				meal.click();
			}
			
			//Card Type
			@FindBy(xpath="//select[@name='creditCard']")
			private WebElement cardtype;
			
			public void cardtype()
			{
				act.clickAndHold(cardtype).sendKeys("").build().perform();
			}
			
			//Card Number
			@FindBy(xpath="//input[@name='creditnumber']")
			private WebElement cardnumber;
			
			public void cardnumber()
			{
				cardnumber.sendKeys("");
			}
			
			//Expiration
			@FindBy(xpath="//select[@name='cc_exp_dt_mn']")
			private WebElement expmonth;
			@FindBy(xpath="//select[@name='cc_exp_dt_yr']")
			private WebElement expyear;
			
			public void expiration()
			{
				act.clickAndHold(expmonth).sendKeys("").build().perform();
				act.clickAndHold(expyear).sendKeys("").build().perform();
			}
			
			//Card First Name
			@FindBy(xpath="//input[@name='cc_frst_name']")
			private WebElement ccfirstname;
			
			public void ccfname()
			{
				ccfirstname.sendKeys("");
			}
			//Card Middle Name
			@FindBy(xpath="//input[@name='cc_mid_name']")
			private WebElement ccmiddlename;
			
			public void ccmname()
			{
				ccmiddlename.sendKeys("");
			}
			
			//Card Last Name
			@FindBy(xpath="//input[@name='cc_last_name']")
			private WebElement cclastname;
			
			public void cclname()
			{
				cclastname.sendKeys("");
			}
			
			//checkbox Ticketless
			@FindBy(xpath="(//input[@name='ticketLess'])[1]")
			private WebElement tktless;
			
			public void tktless()
			{
				tktless.click();
			}
			
			//Billing Address
			@FindBy(xpath="//input[@name='billAddress1']")
			private WebElement baddr1;
			@FindBy(xpath="//input[@name='billAddress2']")
			private WebElement baddr2;
			
			public void billingaddr()
			{
				baddr1.clear();
				baddr1.sendKeys("");
				baddr2.sendKeys("");
			}
			
			// Billing City
			@FindBy(xpath="//input[@name='billCity']")
			private WebElement bcity;
			
			public void bcity()
			{
				bcity.clear();
				bcity.sendKeys("");
			}
			
			//Billing State
			
			@FindBy(xpath="//input[@name='billState']")
			private WebElement billstate;
			
			public void billstate()
			{
			    billstate.clear();
				billstate.sendKeys("");
			}
			
            //Billing Postal Code
			
			@FindBy(xpath="//input[@name='billZip']")
			private WebElement billzip;
			
			public void billzip()
			{
				billzip.clear();
				billzip.sendKeys("");
			}
			
			//Billing State
			@FindBy(xpath="//select[@name='billCountry']")
			private WebElement billcountry;
			
			public void billcountry()
			{
				act.clickAndHold(billcountry).sendKeys("").build().perform();
			}
			
			//checkbox Delivery Address
			@FindBy(xpath="(//input[@name='ticketLess'])[2]")
			private WebElement delcheckbox;
			
			public void delcheckbox()
			{
				delcheckbox.click();
			}
			
			//Delivery Address
			@FindBy(xpath="//input[@name='delAddress1']")
			private WebElement deladdr1;
			@FindBy(xpath="//input[@name='delAddress2']")
			private WebElement deladdr2;
			
			public void deliveryaddr()
			{
				deladdr1.clear();
				deladdr1.sendKeys("");
				deladdr2.sendKeys("");
			}
			
			// Billing City
			@FindBy(xpath="//input[@name='delCity']")
			private WebElement delcity;
			
			public void delcity()
			{
				delcity.clear();
				delcity.sendKeys("");
			}
			
			//Billing State
			
			@FindBy(xpath="//input[@name='delState']")
			private WebElement delstate;
			
			public void deliverystate()
			{
			    delstate.clear();
				delstate.sendKeys("");
			}
			
            //Billing Postal Code
			
			@FindBy(xpath="//input[@name='delZip']")
			private WebElement delzip;
			
			public void delzip()
			{
				billzip.clear();
				billzip.sendKeys("");
			}
			
			//Billing State
			@FindBy(xpath="//select[@name='delCountry']")
			private WebElement delcountry;
			
			public void deliverycountry()
			{
				act.clickAndHold(delcountry).sendKeys("").build().perform();
			}
			
			//Continue Button on Step 3
			@FindBy(xpath="//input[@name='buyFlights']")
			private WebElement continue3;
			
			public void continue3()
			{
				continue3.click();
			}
			
			//Logout Button
			@FindBy(xpath="//img[@src='/images/forms/Logout.gif']")
			private WebElement logout;
			
			public void logout()
			{
				logout.click();
			}
}
