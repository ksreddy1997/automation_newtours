package com.sree.positivetestcases;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.sree.elements.BookFlight_RoundTrip_Elements;
import com.sree.elements.RegPage_Elements;
import com.sree.elements.SignIn_Elements;
import com.sree.setup.DriverSetUp;

public class TC01_ValidData_AllFields {
	
	DriverSetUp ds = new DriverSetUp();
	RegPage_Elements regele;
	SignIn_Elements signele;
	BookFlight_RoundTrip_Elements roundele;
	@BeforeMethod
	@Parameters("browser")
	public void browsersetup(String browser)
	{
		ds.driversetup(browser);
	}
  @Test
  public void registerpage() throws Exception {
	 regele = new RegPage_Elements();
	 
	 regele.registerpage();
	 regele.firstname();
	 regele.lastname();
	 Thread.sleep(5000);
	 regele.phone();
	 regele.email();
	 regele.address();
	 regele.city();
	 regele.state();
	 regele.postal();
	 regele.country();
	 regele.username();
	 regele.password();
	 regele.confirmpassword();
	 regele.submitbutton();
	  
  }
  @Test
  public void signon_Bookflight() throws Exception
  {
	  signele = new SignIn_Elements();
	  
	  signele.signon();
	  signele.signinusername();
	  signele.signinpwd();
	  signele.signsubmit();
	  
	  roundele = new BookFlight_RoundTrip_Elements();
	  
	  roundele.roundtrip();
	  roundele.passcount();
	  roundele.fromport();
	  roundele.ondate();
	  roundele.toport();
	  roundele.todate();
	  roundele.business();
	  roundele.airpreference();
	  roundele.continue1();
	  roundele.depflifghtname();
	  roundele.arrivalflightname();
	  roundele.continue2();
	  roundele.firstname01();
	  roundele.lastname01();
	  roundele.meal();
	  roundele.cardtype();
	  roundele.cardnumber();
	  roundele.expiration();
	  roundele.ccfname();
	  roundele.ccmname();
	  roundele.cclname();
	  roundele.billingaddr();
	  roundele.bcity();
	  roundele.billstate();
	  roundele.billzip();
	  roundele.billcountry();
	  roundele.tktless();
	  roundele.deliveryaddr();
	  roundele.delcity();
	  roundele.deliverystate();
	  roundele.delzip();
	  roundele.deliverycountry();
	  roundele.delcheckbox();
	  Thread.sleep(5000);
	  roundele.continue3();
	  Thread.sleep(5000);
	  
  }
  
  @AfterMethod
  public void browserexit()
  {
	  ds.driverexit();
  }
}
